There are different controllers:
[[06 Controller-Manager]]
[[07 kube-scheduler]]